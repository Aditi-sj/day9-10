package com.stackroute.swaggerautoconfbean.config;

import jakarta.activation.DataSource;
import com.stackroute.swaggerautoconfbean.service.CustomService;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

//implement DataSource interface in CustomDataSource Class to override the methods
public class CustomDataSource implements DataSource{
    @Override
    public InputStream getInputStream() throws IOException {
        return null;
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        return null;
    }

    @Override
    public String getContentType() {
        return "getting the content type";
    }

    @Override
    public String getName() {
        return "get the name";
    }
    //Override the DataSource interface methods

}
