package com.swaggerautoconfbean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerAutoConfBeanApplicationTests {

	@Test
	void contextLoads() {
	}

}
